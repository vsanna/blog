<div class="article__body">
  <?php the_content(); ?>
</div>
