<div class="article__footer">
  <div class="article__section sns-area">
    <div class="fb-share-button" data-href="<?php echo $share_url;?>" data-layout="button_count"></div>
    <a href="https://twitter.com/share" class="twitter-share-button">Tweet</a>
    <a href="http://b.hatena.ne.jp/entry/" class="hatena-bookmark-button" data-hatena-bookmark-layout="standard-balloon" data-hatena-bookmark-lang="ja" title="このエントリーをはてなブックマークに追加"><img src="https://b.st-hatena.com/images/entry-button/button-only@2x.png" alt="このエントリーをはてなブックマークに追加" width="20" height="20" style="border: none;" /></a>
    <a data-pocket-label="pocket" data-pocket-count="horizontal" class="pocket-btn" data-lang="en"></a>
  </div>
  <?php comments_template(); // コメント欄の表示 ?>
</div>
